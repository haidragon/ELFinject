int _start()
{
	asm("nop");
}
